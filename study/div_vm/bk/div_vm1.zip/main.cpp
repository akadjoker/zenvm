// main.cpp — escreve código DIV como string, compila e corre
#include <cstdio>
#include <cmath>
#include "vm.hpp"
#include "compiler.hpp"
#include "process.hpp"

// Testa frame(n) para controlar a velocidade dos processos
// frame(50)  → corre 1 em cada 2 frames (metade da velocidade)
// frame(100) → corre 1x por frame (velocidade normal)
// frame(200) → corre 2x por frame (dobro da velocidade)

static const char* PROGRAM = R"(

process main()
begin
    lento();
    normal();
    rapido();
    frame; frame; frame; frame; frame; frame; frame; frame;
    return;
end

// corre 1x a cada 2 frames (lento)
process lento()
begin
    x = 0;
    loop
        x = x + 1;
        write_pos();
        frame(50);
    end
end

// corre 1x por frame (normal)
process normal()
begin
    x = 0;
    loop
        x = x + 1;
        write_pos();
        frame(100);
    end
end

// corre 2x por frame (rapido)
process rapido()
begin
    x = 0;
    loop
        x = x + 1;
        write_pos();
        frame(200);
    end
end

)";

int main()
{
    VM vm(16, 2048);
    Compiler compiler(vm);

    // write_pos() — imprime x e y do processo corrente
    int FN_WRITE_POS = vm.add_builtin([](VM& vm) {
        Process& me = vm.current_process();
        printf("  %-16s  x=%-6d y=%-6d angle=%d\n",
               me.name.c_str(),
               me.locals[LOC_X],
               me.locals[LOC_Y],
               me.locals[LOC_ANGLE]);
    });
    compiler.register_builtin("write_pos", FN_WRITE_POS);

    // advance(n) — move o processo n unidades na direcção de angle
    // Fiel ao DIV: angle em milésimas de grau (pi=180000, full circle=360000)
    //   x += round(cos(angle * pi / 180000) * n)
    //   y += round(sin(angle * pi / 180000) * n)
    int FN_ADVANCE = vm.add_builtin([](VM& vm) {
        int dist = vm.pop();
        Process& me = vm.current_process();
        double rad = me.locals[LOC_ANGLE] * M_PI / 180000.0;
        me.locals[LOC_X] += (int)std::round(std::cos(rad) * dist);
        me.locals[LOC_Y] += (int)std::round(std::sin(rad) * dist);
    });
    compiler.register_builtin("advance", FN_ADVANCE);

    // get_distx(angle, dist) — componente X de mover 'dist' em 'angle'
    int FN_DISTX = vm.add_builtin([](VM& vm) {
        int dist  = vm.pop();
        int angle = vm.pop();
        double rad = angle * M_PI / 180000.0;
        vm.push((int)std::round(std::cos(rad) * dist));
    });
    compiler.register_builtin("get_distx", FN_DISTX);

    // get_disty(angle, dist) — componente Y
    int FN_DISTY = vm.add_builtin([](VM& vm) {
        int dist  = vm.pop();
        int angle = vm.pop();
        double rad = angle * M_PI / 180000.0;
        vm.push((int)std::round(std::sin(rad) * dist));
    });
    compiler.register_builtin("get_disty", FN_DISTY);

    // near_angle(a1, a2, inc) — aproxima a1 de a2 em incrementos de inc
    int FN_NEAR_ANGLE = vm.add_builtin([](VM& vm) {
        int inc = vm.pop();
        int a2  = vm.pop();
        int a1  = vm.pop();
        // normaliza diferença para [-180000, 180000]
        int diff = ((a2 - a1) % 360000 + 540000) % 360000 - 180000;
        if      (diff >  inc) a1 += inc;
        else if (diff < -inc) a1 -= inc;
        else                  a1  = a2;
        vm.push(((a1 % 360000) + 360000) % 360000);
    });
    compiler.register_builtin("near_angle", FN_NEAR_ANGLE);

    printf("=== compilar ===\n");
    try {
        compiler.compile(PROGRAM);
    } catch (const std::exception& e) {
        printf("ERRO: %s\n", e.what());
        return 1;
    }
    printf("código: %zu words\n\n", vm.code.size());

    int main_entry = compiler.entry_of("main");
    if (main_entry < 0) { printf("'main' não encontrado\n"); return 1; }

    vm.run(main_entry, "main", 100);
    printf("\n=== fim ===\n");
    return 0;
}

