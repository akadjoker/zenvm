#pragma once
#include <vector>
#include <string>

// Número de variáveis locais por processo (equivale a iloc_len do DIV)
static constexpr int LOCALS_SIZE    = 64;
static constexpr int PROC_STACK_SIZE = 256;

// Offsets das variáveis locais predefinidas (= ltobj.def 'local' declarations)
static constexpr int LOC_X          = 0;
static constexpr int LOC_Y          = 1;
static constexpr int LOC_ANGLE      = 2;
static constexpr int LOC_GRAPH      = 3;
static constexpr int LOC_SIZE       = 4;
static constexpr int LOC_FLAGS      = 5;
static constexpr int LOC_FILE       = 6;
static constexpr int LOC_USER_START = 7;   // user vars começam aqui

enum class ProcessStatus {
    ALIVE    = 2,
    DEAD     = 0,
    SLEEPING = 3,
    FROZEN   = 4,
};

// ============================================================
// Process — equivale ao bloco mem[id .. id+iloc_len] do DIV
// ============================================================
struct Process {
    int           id     = -1;
    std::string   name;
    ProcessStatus status = ProcessStatus::ALIVE;

    int  priority            = 100;
    bool executed_this_frame = false;
    int  frame_accum         = 0;

    // ip e sp salvos quando o processo faz FRAME (= _IP, _SP do DIV)
    int saved_ip = 0;
    int saved_sp = -1;

    // Stack própria — isolada por processo (no DIV era uma zona da pila global)
    std::vector<int> stack  = std::vector<int>(PROC_STACK_SIZE, 0);

    // Variáveis locais predefinidas + user vars
    // locals[0]=x, [1]=y, [2]=angle, [3]=graph, [4]=size, [5]=flags, [6]=file
    std::vector<int> locals = std::vector<int>(LOCALS_SIZE, 0);

    int father_id = -1;
    int caller_id = -1;

    Process() { locals[LOC_SIZE] = 100; }  // size=100 por defeito (como DIV)
};
