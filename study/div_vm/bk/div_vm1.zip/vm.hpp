#pragma once
#include <vector>
#include <string>
#include <functional>
#include "opcodes.hpp"
#include "process.hpp"

class VM {
public:
    // -----------------------------------------------------------------------
    // Memória
    // -----------------------------------------------------------------------
    std::vector<int> code;       // bytecode (só leitura)
    std::vector<int> globals;    // variáveis globais partilhadas

    // -----------------------------------------------------------------------
    // Estado de execução corrente
    // sp e stack pertencem ao PROCESSO corrente; são copiados para cá
    // no início de run_until_yield e guardados de volta ao fazer FRAME.
    // -----------------------------------------------------------------------
    int current_id = -1;
    int ip         = 0;
    int sp         = -1;   // sp vivo durante a execução (= pila[] offset do DIV)

    // -----------------------------------------------------------------------
    // Processos — lista de todos os processos vivos/mortos
    // No DIV eram blocos contíguos em mem[]; aqui é um vector de structs
    // -----------------------------------------------------------------------
    std::vector<Process> processes;

    // -----------------------------------------------------------------------
    // Funções built-in (write, signal, get_key, ...)
    // -----------------------------------------------------------------------
    using BuiltinFn = std::function<void(VM&)>;
    std::vector<BuiltinFn> builtins;
    int add_builtin(BuiltinFn fn);

    // -----------------------------------------------------------------------
    // Helpers de stack — operam na stack do processo corrente
    // -----------------------------------------------------------------------
    void push(int v) { current_process().stack[++sp] = v; }
    int  pop()       { return current_process().stack[sp--]; }
    int& top()       { return current_process().stack[sp]; }

    // -----------------------------------------------------------------------
    // API pública
    // -----------------------------------------------------------------------
    VM(int globals_size = 256, int stack_size = 2048);

    // Spawna o processo principal e arranca o loop de frames
    void run(int entry_point, const std::string& name = "main", int priority = 100);

    // Spawna um processo manualmente (usado também pelo opcode SPAWN)
    int  spawn(int entry_point, const std::string& name, int priority, int father_id = -1);

    // Acesso ao processo corrente
    Process& current_process();
    Process* find(int id);

private:
    int next_id = 0;

    // Corre o processo corrente até FRAME/FRAME_N ou RETURN
    // Devolve true se fez yield, false se morreu
    bool run_until_yield();

    // Uma frame do scheduler — espelho do exec_process() do DIV (i.cpp)
    // 1. Reset executed_this_frame em todos
    // 2. Loop: escolhe o de maior prioridade ainda por executar
    // 3. Verifica frame_accum — se >=100 desconta e salta (não corre)
    // 4. Restaura ip, corre, guarda ip
    void tick();
};
