#include "vm.hpp"
#include <algorithm>
#include <cstdio>

VM::VM(int globals_size, int /*stack_size*/)
{
    globals.resize(globals_size, 0);
    // stack por processo — não há stack global
}

// ---------------------------------------------------------------------------
int VM::add_builtin(BuiltinFn fn)
{
    builtins.push_back(std::move(fn));
    return (int)builtins.size() - 1;
}

// ---------------------------------------------------------------------------
Process& VM::current_process() { return *find(current_id); }

Process* VM::find(int id)
{
    for (auto& p : processes)
        if (p.id == id) return &p;
    return nullptr;
}

// ---------------------------------------------------------------------------
int VM::spawn(int entry_point, const std::string& name, int priority, int father_id)
{
    Process p;
    p.id         = next_id++;
    p.name       = name;
    p.status     = ProcessStatus::ALIVE;
    p.priority   = priority;
    p.saved_ip   = entry_point;
    p.frame_accum = 0;
    p.father_id  = father_id;
    p.caller_id  = current_id;
    processes.push_back(std::move(p));
    return processes.back().id;
}

// ---------------------------------------------------------------------------
// run_until_yield — espelho do nucleo_exec() do DIV (kernel.cpp)
// Corre opcodes do processo corrente até FRAME, FRAME_N, RETURN ou NOP.
// ---------------------------------------------------------------------------
bool VM::run_until_yield()
{
    Process* me = find(current_id);
    auto& stk   = me->stack;   // alias para a stack deste processo

    while (true) {
        Op op = static_cast<Op>(code[ip++]);

        switch (op) {

        case Op::NOP:
            me->status = ProcessStatus::DEAD;
            return false;

        // ---- globais (partilhadas, endereço absoluto) --------------------
        // Equivale a tvglo do DIV: mem[offset_fixo]
        case Op::LOAD_GLOBAL:
            push(globals[code[ip++]]);
            break;

        case Op::STORE_GLOBAL:
            globals[code[ip++]] = pop();
            break;

        // ---- locais (por processo, endereço relativo) --------------------
        // Equivale a tvloc do DIV: mem[id + offset]
        // No DIV o acesso era: PUSH offset; laid; DEREF
        // Aqui encapsulamos nos opcodes LOAD/STORE_LOCAL
        case Op::LOAD_LOCAL:
            push(me->locals[code[ip++]]);
            break;

        case Op::STORE_LOCAL:
            me->locals[code[ip++]] = pop();
            break;

        // ---- literal -----------------------------------------------------
        case Op::PUSH_CONST:
            push(code[ip++]);
            break;

        // ---- aritmética — inline como o DIV (sem chamadas) ---------------
        case Op::ADD: stk[sp-1] += stk[sp]; sp--; break;
        case Op::SUB: stk[sp-1] -= stk[sp]; sp--; break;
        case Op::MUL: stk[sp-1] *= stk[sp]; sp--; break;
        case Op::DIV: stk[sp-1] /= stk[sp]; sp--; break;
        case Op::NEG: stk[sp]   = -stk[sp]; break;
        case Op::MOD: stk[sp-1] %= stk[sp]; sp--; break;

        // ---- bitwise (= land, lor, lxor, lnot do DIV) -----------------------
        case Op::BAND: stk[sp-1] &= stk[sp]; sp--; break;
        case Op::BOR:  stk[sp-1] |= stk[sp]; sp--; break;
        case Op::BXOR: stk[sp-1] ^= stk[sp]; sp--; break;
        case Op::BNOT: stk[sp]    = ~stk[sp]; break;

        // ---- lógico (resultado 0 ou 1) ---------------------------------------
        case Op::AND: stk[sp-1] = (stk[sp-1] && stk[sp]) ? 1 : 0; sp--; break;
        case Op::OR:  stk[sp-1] = (stk[sp-1] || stk[sp]) ? 1 : 0; sp--; break;
        case Op::NOT: stk[sp]   = stk[sp] ? 0 : 1; break;

        // ---- comparação --------------------------------------------------
        case Op::EQ:  stk[sp-1] = (stk[sp-1] == stk[sp]) ? 1 : 0; sp--; break;
        case Op::NEQ: stk[sp-1] = (stk[sp-1] != stk[sp]) ? 1 : 0; sp--; break;
        case Op::GT:  stk[sp-1] = (stk[sp-1] >  stk[sp]) ? 1 : 0; sp--; break;
        case Op::LT:  stk[sp-1] = (stk[sp-1] <  stk[sp]) ? 1 : 0; sp--; break;
        case Op::GTE: stk[sp-1] = (stk[sp-1] >= stk[sp]) ? 1 : 0; sp--; break;
        case Op::LTE: stk[sp-1] = (stk[sp-1] <= stk[sp]) ? 1 : 0; sp--; break;

        // ---- saltos ------------------------------------------------------
        // ljmp do DIV: ip = mem[ip]
        case Op::JUMP:
            ip = code[ip];
            break;

        // ljpf do DIV: if (pila[sp--]&1) ip++; else ip=mem[ip]
        case Op::JUMP_FALSE:
            if (stk[sp--] & 1) ip++;
            else                 ip = code[ip];
            break;

        // ---- id do processo corrente (= lcid do DIV) --------------------
        case Op::LOAD_ID:
            push(current_id);
            break;

        // ---- built-in (= lfun do DIV) ------------------------------------
        case Op::CALL_BUILTIN:
            builtins[code[ip++]](*this);
            break;

        // ---- pop / dup ---------------------------------------------------
        case Op::POP:
            sp--;
            break;

        // ldup do DIV — duplica TOS (usado em compound assigns de arrays)
        case Op::DUP:
            push(stk[sp]);
            break;

        // ---- arrays com índice runtime (= lptr + lasi/lcar do DIV) ----------
        // LOAD_GLOBAL_IDX base: pop idx → globals[base+idx]
        case Op::LOAD_GLOBAL_IDX: {
            int base = code[ip++];
            int idx  = stk[sp--];
            push(globals[base + idx]);
            break;
        }
        // STORE_GLOBAL_IDX base: pop val(TOS), pop idx → globals[base+idx]=val
        case Op::STORE_GLOBAL_IDX: {
            int base = code[ip++];
            int val  = stk[sp--];
            int idx  = stk[sp--];
            globals[base + idx] = val;
            break;
        }
        case Op::LOAD_LOCAL_IDX: {
            int base = code[ip++];
            int idx  = stk[sp--];
            push(me->locals[base + idx]);
            break;
        }
        case Op::STORE_LOCAL_IDX: {
            int base = code[ip++];
            int val  = stk[sp--];
            int idx  = stk[sp--];
            me->locals[base + idx] = val;
            break;
        }

        // ---- switch/case (= lcse, lcsr do DIV) -------------------------------
        // CASE_EQ addr: pop case_val; se TOS(switch_val)!=case_val → jump
        case Op::CASE_EQ: {
            int addr     = code[ip++];
            int case_val = stk[sp--];
            if (stk[sp] != case_val) ip = addr;
            break;
        }
        // CASE_RNG addr: pop hi; pop lo; se TOS fora [lo,hi] → jump
        case Op::CASE_RNG: {
            int addr = code[ip++];
            int hi   = stk[sp--];
            int lo   = stk[sp--];
            if (stk[sp] < lo || stk[sp] > hi) ip = addr;
            break;
        }

        // ---- spawn (= lcal do DIV) ---------------------------------------
        // Cria processo filho. Operandos: entry, priority.
        // Deixa o id do filho no topo da stack.
        case Op::SPAWN: {
            int entry    = code[ip++];
            int pri      = code[ip++];
            // Guarda antes de push_back invalidar ponteiros
            int me_id    = current_id;
            int child_id = spawn(entry, "proc_" + std::to_string(next_id-1), pri, me_id);
            // re-fetch me porque spawn() pode ter realocado o vector
            me = find(current_id);
            push(child_id);
            printf("  [SPAWN] '%s' (id=%d) criou filho id=%d entry=0x%x pri=%d\n",
                   me->name.c_str(), me_id, child_id, entry, pri);
            break;
        }

        // ---- return (= lret do DIV) --------------------------------------
        case Op::RETURN:
            me->status = ProcessStatus::DEAD;
            printf("  [RETURN] '%s' (id=%d) morreu\n", me->name.c_str(), me->id);
            return false;

        // ---- frame (= lfrm do DIV) ---------------------------------------
        // Yield normal: suspende sempre, retoma na próxima frame.
        case Op::FRAME:
            me->saved_ip = ip;
            me->saved_sp = sp;   // guarda stack pointer (= guarda_pila do DIV)
            return true;

        // ---- frame(n) (= lfrf do DIV) ------------------------------------
        // Yield parcial: acumula n no frame_accum.
        // Só suspende de verdade quando frame_accum >= 100.
        // Permite processos a correr a velocidades diferentes.
        //
        // Exemplos:
        //   frame(50)  → corre 1 em cada 2 frames  (metade da velocidade)
        //   frame(100) → corre 1 vez por frame      (igual a frame;)
        //   frame(200) → corre 2 vezes por frame    (dobro da velocidade)
        case Op::FRAME_N: {
            int n = code[ip++];                  // percentagem de frame
            me->frame_accum += n;
            if (me->frame_accum >= 100) {
                me->frame_accum -= 100;
                me->saved_ip = ip;
                me->saved_sp = sp;               // guarda stack pointer
                return true;                     // yield real
            }
            break;
        }

        default:
            printf("  [VM] opcode desconhecido %d no ip=%d\n",
                   static_cast<int>(op), ip-1);
            me->status = ProcessStatus::DEAD;
            return false;
        }
    }
}

// ---------------------------------------------------------------------------
// tick — uma frame do scheduler
// Espelho fiel do exec_process() de i.cpp do DIV original:
//
//   1. Reset executed_this_frame em todos os processos
//   2. Loop:
//      a. Encontra o processo ALIVE com maior prioridade não executado
//      b. Se frame_accum >= 100: desconta 100, marca executado, salta (não corre)
//      c. Senão: restaura ip, corre, guarda ip, marca executado
//   3. Remove processos DEAD
// ---------------------------------------------------------------------------
void VM::tick()
{
    // 1. reset
    for (auto& p : processes)
        p.executed_this_frame = false;

    // 2. loop de scheduling
    while (true) {
        // a. escolhe o processo com maior prioridade ainda por executar
        Process* chosen = nullptr;
        for (auto& p : processes) {
            if (p.status != ProcessStatus::ALIVE) continue;
            if (p.executed_this_frame)            continue;
            if (!chosen || p.priority > chosen->priority)
                chosen = &p;
        }
        if (!chosen) break;

        // b. frame_accum >= 100 → este processo está "adiantado",
        //    salta esta frame sem executar (exatamente como o DIV)
        if (chosen->frame_accum >= 100) {
            chosen->frame_accum -= 100;
            chosen->executed_this_frame = true;
            continue;
        }

        // c. corre o processo
        current_id = chosen->id;
        ip         = chosen->saved_ip;
        sp         = chosen->saved_sp;   // restaura stack pointer (= carga_pila do DIV)

        run_until_yield();

        // re-fetch (run_until_yield pode ter realocado via SPAWN)
        Process* p = find(current_id);
        if (p) p->executed_this_frame = true;
    }

    // 3. remove mortos
    processes.erase(
        std::remove_if(processes.begin(), processes.end(),
            [](const Process& p){ return p.status == ProcessStatus::DEAD; }),
        processes.end());
}

// ---------------------------------------------------------------------------
void VM::run(int entry_point, const std::string& name, int priority)
{
    spawn(entry_point, name, priority);

    int frame_n = 0;
    while (!processes.empty()) {
        printf("\n=== FRAME %d  (%zu processo(s) vivo(s)) ===\n",
               frame_n++, processes.size());

        // mostra o estado de todos os processos no início da frame
        for (auto& p : processes)
            printf("  proc '%s' id=%d pri=%d frame_accum=%d ip=0x%x\n",
                   p.name.c_str(), p.id, p.priority, p.frame_accum, p.saved_ip);
        printf("---\n");

        tick();

        if (frame_n > 200) { printf("[VM] limite de frames\n"); break; }
    }
}
