// main.cpp — escreve código DIV como string, compila e corre
#include <cstdio>
#include <cmath>
#include "vm.hpp"
#include "compiler.hpp"
#include "process.hpp"

// Testa frame(n) para controlar a velocidade dos processos
// frame(50)  → corre 1 em cada 2 frames (metade da velocidade)
// frame(100) → corre 1x por frame (velocidade normal)
// frame(200) → corre 2x por frame (dobro da velocidade)

static const char* PROGRAM = R"(

process main()
begin
    lento();
    normal();
    rapido();
    frame; frame; frame; frame; frame; frame; frame; frame;
    return;
end

// corre 1x a cada 2 frames (lento)
process lento()
begin
    x = 0;
    loop
        x = x + 1;
        write_pos();
        frame(50);
    end
end

// corre 1x por frame (normal)
process normal()
begin
    x = 0;
    loop
        x = x + 1;
        write_pos();
        frame(100);
    end
end

// corre 2x por frame (rapido)
process rapido()
begin
    x = 0;
    loop
        x = x + 1;
        write_pos();
        frame(200);
    end
end

)";

// ---------------------------------------------------------------------------
// Builtins — funções C normais, sem lambdas nem capturas
// ---------------------------------------------------------------------------
static void builtin_write_pos(VM& vm) {
    Process& me = vm.current_process();
    printf("  %-16s  x=%-6d y=%-6d angle=%d\n",
           me.name.c_str(),
           me.locals[LOC_X],
           me.locals[LOC_Y],
           me.locals[LOC_ANGLE]);
}

static void builtin_advance(VM& vm) {
    int dist     = vm.pop();
    Process& me  = vm.current_process();
    double rad   = me.locals[LOC_ANGLE] * M_PI / 180000.0;
    me.locals[LOC_X] += (int)std::round(std::cos(rad) * dist);
    me.locals[LOC_Y] += (int)std::round(std::sin(rad) * dist);
}

static void builtin_get_distx(VM& vm) {
    int dist  = vm.pop();
    int angle = vm.pop();
    vm.push((int)std::round(std::cos(angle * M_PI / 180000.0) * dist));
}

static void builtin_get_disty(VM& vm) {
    int dist  = vm.pop();
    int angle = vm.pop();
    vm.push((int)std::round(std::sin(angle * M_PI / 180000.0) * dist));
}

static void builtin_near_angle(VM& vm) {
    int inc  = vm.pop();
    int a2   = vm.pop();
    int a1   = vm.pop();
    int diff = ((a2 - a1) % 360000 + 540000) % 360000 - 180000;
    if      (diff >  inc) a1 += inc;
    else if (diff < -inc) a1 -= inc;
    else                  a1  = a2;
    vm.push(((a1 % 360000) + 360000) % 360000);
}

int main()
{
    VM vm(16, 2048);
    Compiler compiler(vm);

    compiler.register_builtin("write_pos",   vm.add_builtin(builtin_write_pos));
    compiler.register_builtin("advance",     vm.add_builtin(builtin_advance));
    compiler.register_builtin("get_distx",   vm.add_builtin(builtin_get_distx));
    compiler.register_builtin("get_disty",   vm.add_builtin(builtin_get_disty));
    compiler.register_builtin("near_angle",  vm.add_builtin(builtin_near_angle));

    printf("=== compilar ===\n");
    try {
        compiler.compile(PROGRAM);
    } catch (const std::exception& e) {
        printf("ERRO: %s\n", e.what());
        return 1;
    }
    printf("código: %zu words\n\n", vm.code.size());

    int main_entry = compiler.entry_of("main");
    if (main_entry < 0) { printf("'main' não encontrado\n"); return 1; }

    vm.run(main_entry, "main", 100);
    printf("\n=== fim ===\n");
    return 0;
}

