#pragma once
#include <vector>
#include <string>

static constexpr int LOCALS_SIZE     = 64;
static constexpr int PROC_STACK_SIZE = 256;

static constexpr int LOC_X          = 0;
static constexpr int LOC_Y          = 1;
static constexpr int LOC_ANGLE      = 2;
static constexpr int LOC_GRAPH      = 3;
static constexpr int LOC_SIZE       = 4;
static constexpr int LOC_FLAGS      = 5;
static constexpr int LOC_FILE       = 6;
static constexpr int LOC_USER_START = 7;

enum class ProcessStatus { ALIVE=2, DEAD=0, SLEEPING=3, FROZEN=4 };

// Frame de chamada de função — guardado no call_stack do processo
// quando se executa FUNC_CALL, restaurado em FUNC_RET.
struct CallFrame {
    int              ret_ip;
    std::vector<int> saved_locals;
};

struct Process {
    int           id     = -1;
    std::string   name;
    ProcessStatus status = ProcessStatus::ALIVE;

    int  priority            = 100;
    bool executed_this_frame = false;
    int  frame_accum         = 0;

    int saved_ip = 0;
    int saved_sp = -1;

    std::vector<int>       stack      = std::vector<int>(PROC_STACK_SIZE, 0);
    std::vector<int>       locals     = std::vector<int>(LOCALS_SIZE, 0);
    std::vector<CallFrame> call_stack; // frames de funções chamadas por este processo

    int father_id = -1;
    int caller_id = -1;

    Process() { locals[LOC_SIZE] = 100; }
};
