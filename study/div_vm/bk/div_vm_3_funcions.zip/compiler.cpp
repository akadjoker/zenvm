#include "compiler.hpp"
#include "process.hpp"
#include <cctype>
#include <stdexcept>
#include <cstring>
#include <cstdio>
#include <algorithm>

// ============================================================================
// Construtor
// ============================================================================
Compiler::Compiler(VM& vm) : vm(vm) {}

void Compiler::register_builtin(const std::string& name, int builtin_index)
{
    Symbol s;
    s.name   = name;
    s.kind   = SymKind::BUILTIN;
    s.offset = builtin_index;
    syms.push_back(s);
}

// ============================================================================
// Lexer — equivale ao lexico() do DIV
// Lê o próximo token de *src e avança o cursor.
// Resultado em: pieza, num_val, id_val
// ============================================================================
void Compiler::lexico()
{
    // salta espaços e comentários  //
    while (true) {
        while (*src && std::isspace((unsigned char)*src)) src++;
        if (src[0]=='/' && src[1]=='/') {
            while (*src && *src!='\n') src++;
        } else break;
    }

    if (!*src) { pieza = Token::END_OF_FILE; return; }

    // número
    if (std::isdigit((unsigned char)*src)) {
        num_val = 0;
        while (std::isdigit((unsigned char)*src)) num_val = num_val*10 + (*src++ - '0');
        pieza = Token::NUMBER;
        return;
    }

    // identificador ou palavra reservada
    if (std::isalpha((unsigned char)*src) || *src=='_') {
        id_val.clear();
        while (std::isalnum((unsigned char)*src) || *src=='_') id_val += *src++;

        // tabela de palavras reservadas (= vhash[] do DIV mas simples)
        struct { const char* w; Token t; } kw[] = {
            {"program",  Token::PROGRAM},  {"process",  Token::PROCESS},
            {"global",   Token::GLOBAL},   {"local",    Token::LOCAL},
            {"private",  Token::PRIVATE},  {"const",    Token::CONST},
            {"begin",    Token::BEGIN},    {"end",      Token::END},
            {"if",       Token::IF},       {"else",     Token::ELSE},
            {"while",    Token::WHILE},    {"loop",     Token::LOOP},
            {"repeat",   Token::REPEAT},   {"until",    Token::UNTIL},
            {"from",     Token::FROM},     {"to",       Token::TO},
            {"step",     Token::STEP},     {"for",      Token::FOR},
            {"switch",   Token::SWITCH},   {"case",     Token::CASE},
            {"default",  Token::DEFAULT},
            {"break",    Token::BREAK},    {"continue", Token::CONTINUE},
            {"frame",    Token::FRAME},    {"return",   Token::RETURN},
            {"int",      Token::INT_KW},
            {"function", Token::FUNCTION},
            {"and",      Token::AND_KW},   {"or",       Token::OR_KW},
            {"not",      Token::NOT_KW},
        };
        for (auto& k : kw)
            if (id_val == k.w) { pieza = k.t; return; }

        pieza = Token::IDENT;
        return;
    }

    // operadores e pontuação
    char c = *src++;
    switch (c) {
        case '=':
            if (*src=='=') { src++; pieza = Token::EQ_OP; }
            else                   pieza = Token::ASSIGN;
            return;
        case '!': if (*src=='=') { src++; pieza = Token::NEQ; } else pieza = Token::NOT_OP;  return;
        case '>': if (*src=='=') { src++; pieza = Token::GTE; } else pieza = Token::GT;      return;
        case '<': if (*src=='=') { src++; pieza = Token::LTE; } else pieza = Token::LT;      return;
        case '+':                                                                              // + += ++
            if      (*src=='+') { src++; pieza = Token::INC;        }
            else if (*src=='=') { src++; pieza = Token::ADD_ASSIGN;  }
            else                         pieza = Token::PLUS;
            return;
        case '-':                                                                              // - -= --
            if      (*src=='-') { src++; pieza = Token::DEC;        }
            else if (*src=='=') { src++; pieza = Token::SUB_ASSIGN;  }
            else                         pieza = Token::MINUS;
            return;
        case '*':
            if (*src=='=') { src++; pieza = Token::MUL_ASSIGN; } else pieza = Token::STAR;   return;
        case '/':
            if (*src=='=') { src++; pieza = Token::DIV_ASSIGN; } else pieza = Token::SLASH;  return;
        case '%':
            if (*src=='=') { src++; pieza = Token::MOD_ASSIGN; } else pieza = Token::MOD_OP; return;
        case '&':
            if (*src=='&') { src++; pieza = Token::AND_OP; } else pieza = Token::BAND_OP;    return;
        case '|':
            if (*src=='|') { src++; pieza = Token::OR_OP;  } else pieza = Token::BOR_OP;     return;
        case '^': pieza = Token::BXOR_OP;  return;
        case '(': pieza = Token::LPAREN;   return;
        case ')': pieza = Token::RPAREN;   return;
        case '[': pieza = Token::LBRACKET; return;
        case ']': pieza = Token::RBRACKET; return;
        case ';': pieza = Token::SEMICOLON; return;
        case ':': pieza = Token::COLON;     return;
        case ',': pieza = Token::COMMA;    return;
        case '.':
            if (*src=='.') { src++; pieza = Token::DOTDOT; }  // range em switch: 1..5
            else error("caracter '.' inesperado");
            return;
        default:
            error(std::string("char desconhecido: ") + c);
    }
}

// ============================================================================
// Symbol table
// ============================================================================
Symbol* Compiler::find_sym(const std::string& name, SymKind /*scope_kind*/)
{
    // procura primeiro locais do processo corrente, depois globais
    // (equivale ao lookup em vhash[] com bloque_lexico do DIV)
    Symbol* found = nullptr;
    for (auto& s : syms)
        if (s.name == name) { found = &s; /* continua — último encontrado tem prioridade (locais sobrepõem globais) */ }
    return found;
}

Symbol& Compiler::add_global(const std::string& name, int array_len)
{
    Symbol s;
    s.name      = name;
    s.kind      = SymKind::GLOBAL;
    s.offset    = next_global;
    s.array_len = array_len;
    int slots   = (array_len >= 0) ? (array_len + 1) : 1;  // array[N] = N+1 elementos
    next_global += slots;
    syms.push_back(s);
    if ((int)vm.globals.size() < next_global) vm.globals.resize(next_global, 0);
    return syms.back();
}

Symbol& Compiler::add_local(const std::string& name, int array_len)
{
    Symbol s;
    s.name      = name;
    s.kind      = SymKind::LOCAL;
    s.offset    = next_local;
    s.array_len = array_len;
    int slots   = (array_len >= 0) ? (array_len + 1) : 1;
    next_local += slots;
    return syms.push_back(s), syms.back();
}

Symbol& Compiler::add_process(const std::string& name, int entry)
{
    Symbol s; s.name = name; s.kind = SymKind::PROCESS; s.offset = entry;
    syms.push_back(s);
    return syms.back();
}

// ============================================================================
// Helpers
// ============================================================================
void Compiler::error(const std::string& msg)
{
    throw std::runtime_error("[compiler] " + msg + " (proximo token: '" + id_val + "')");
}

void Compiler::expect(Token t, const char* msg)
{
    if (pieza != t) error(std::string("esperava ") + msg);
    lexico();
}

bool Compiler::match(Token t)
{
    if (pieza != t) {
        // : e ; são intercambiáveis (DIV usa ; mas sintaxe C usa :)
        if (t == Token::SEMICOLON && pieza == Token::COLON) { lexico(); return true; }
        if (t == Token::COLON && pieza == Token::SEMICOLON) { lexico(); return true; }
        return false;
    }
    lexico(); return true;
}

// ============================================================================
// PARSE — ponto de entrada
// ============================================================================
int Compiler::compile(const std::string& source)
{
    src = source.c_str();
    lexico();           // lê o primeiro token (= primeiro lexico() no DIV)
    parse_program();
    return 0;           // entry point do primeiro processo registado
}

// ============================================================================
// parse_program
// Equivale ao sintactico() do DIV
// ============================================================================
void Compiler::parse_program()
{
    // secção global opcional
    if (check(Token::GLOBAL)) {
        lexico();
        parse_global_section();
    }

    // um ou mais processos e/ou funções (em qualquer ordem)
    while (check(Token::PROCESS) || check(Token::FUNCTION)) {
        if (check(Token::PROCESS)) parse_process();
        else                       parse_function();
    }

    if (!check(Token::END_OF_FILE))
        error("esperava 'process', 'function' ou fim de ficheiro");
}

// ============================================================================
// parse_global_section
// global
//   x = 10;
//   y;
// end
// ============================================================================
void Compiler::parse_global_section()
{
    // lê variáveis até encontrar 'end'
    while (!check(Token::END) && !check(Token::END_OF_FILE)) {
        if (check(Token::INT_KW)) lexico(); // tipo opcional
        if (!check(Token::IDENT)) error("esperava nome de variável global");
        std::string name = id_val; lexico();

        int array_len = -1;
        if (check(Token::LBRACKET)) {  // tabela[N] — = ttglo do DIV
            lexico();
            if (!check(Token::NUMBER)) error("esperava tamanho do array");
            array_len = num_val; lexico();
            expect(Token::RBRACKET, "']'");
        }

        Symbol& s = add_global(name, array_len);
        if (array_len < 0 && match(Token::ASSIGN)) {
            // inicialização escalar: x = 10;
            if (!check(Token::NUMBER)) error("esperava literal numérico");
            vm.globals[s.offset] = num_val;
            lexico();
        }
        match(Token::SEMICOLON);
    }
    expect(Token::END, "'end' depois de 'global'");
    match(Token::SEMICOLON);
}

// ============================================================================
// parse_process
// process nome()
// [local x = 0; end]
// begin
//   statements
// end
// ============================================================================
void Compiler::parse_process()
{
    expect(Token::PROCESS, "'process'");
    if (!check(Token::IDENT)) error("esperava nome do processo");
    std::string proc_name = id_val; lexico();
    current_process = proc_name;

    // parâmetros — por agora ignorados mas consumidos
    expect(Token::LPAREN, "'('");
    expect(Token::RPAREN, "')'");
    match(Token::SEMICOLON);

    // reset locais para este processo (= iloc=0 no DIV para cada processo)
    // Remove locais anteriores do scope (simplificado)
    syms.erase(std::remove_if(syms.begin(), syms.end(),
        [](const Symbol& s){ return s.kind == SymKind::LOCAL; }), syms.end());

    // Pré-regista variáveis locais predefinidas (= ltobj.def 'local' declarations)
    // Todos os processos têm estas variáveis automaticamente, como no DIV.
    auto pre = [&](const char* nm, int off) {
        Symbol s; s.name = nm; s.kind = SymKind::LOCAL; s.offset = off;
        syms.push_back(s);
    };
    pre("x",     LOC_X);
    pre("y",     LOC_Y);
    pre("angle", LOC_ANGLE);
    pre("graph", LOC_GRAPH);
    pre("size",  LOC_SIZE);
    pre("flags", LOC_FLAGS);
    pre("file",  LOC_FILE);
    next_local = LOC_USER_START;

    // entry point: ANTES das secções local/private para que o código de
    // inicialização de variáveis fique dentro do corpo do processo.
    int entry = here();
    add_process(proc_name, entry);
    auto it = forward_holes.find(proc_name);
    if (it != forward_holes.end()) {
        for (int h : it->second) vm.code[h] = entry;
        forward_holes.erase(it);
    }

    // secção local opcional
    if (check(Token::LOCAL)) { lexico(); parse_local_section(); }
    // secção private opcional
    if (check(Token::PRIVATE)) { lexico(); parse_private_section(); }

    expect(Token::BEGIN, "'begin'");
    match(Token::SEMICOLON);

    while (!check(Token::END) && !check(Token::END_OF_FILE))
        sentencia();

    expect(Token::END, "'end'");
    match(Token::SEMICOLON);

    g1(Op::RETURN);
}

// ============================================================================
// parse_function
// function nome(a, b)
// begin
//   statements
// end
// Parâmetros tornam-se locals[0], locals[1], ...
// FUNC_CALL guarda/restaura locals e ip automaticamente.
// ============================================================================
void Compiler::parse_function()
{
    expect(Token::FUNCTION, "'function'");
    if (!check(Token::IDENT)) error("esperava nome da função");
    std::string fn_name = id_val; lexico();
    current_process = fn_name;

    // reset locais (funções não têm predefined locals; parâmetros começam em 0)
    syms.erase(std::remove_if(syms.begin(), syms.end(),
        [](const Symbol& s){ return s.kind == SymKind::LOCAL; }), syms.end());
    next_local = 0;

    expect(Token::LPAREN, "'('");
    int nparams = 0;
    if (!check(Token::RPAREN)) {
        do {
            if (!check(Token::IDENT)) error("esperava nome de parâmetro");
            add_local(id_val);
            nparams++;
            lexico();
        } while (match(Token::COMMA));
    }
    expect(Token::RPAREN, "')'");
    match(Token::SEMICOLON);

    // secção local opcional (variáveis adicionais da função)
    if (check(Token::LOCAL)) {
        lexico();
        parse_local_section();
    }

    // regista na symbol table (antes do corpo para suportar recursão)
    int entry = here();
    {
        Symbol s;
        s.name    = fn_name;
        s.kind    = SymKind::FUNCTION;
        s.offset  = entry;
        s.nparams = nparams;
        syms.push_back(s);
    }

    // resolve forward refs (improvavável mas possível)
    auto it = forward_holes.find(fn_name);
    if (it != forward_holes.end()) {
        for (int h : it->second) vm.code[h] = entry;
        forward_holes.erase(it);
    }

    expect(Token::BEGIN, "'begin'");
    match(Token::SEMICOLON);

    in_function = true;
    while (!check(Token::END) && !check(Token::END_OF_FILE))
        sentencia();
    in_function = false;

    expect(Token::END, "'end'");
    match(Token::SEMICOLON);

    // return 0 implícito
    g2(Op::PUSH_CONST, 0);
    g1(Op::FUNC_RET);
}

void Compiler::parse_local_section()
{
    while (!check(Token::END) && !check(Token::END_OF_FILE)) {
        if (check(Token::INT_KW)) lexico();
        if (!check(Token::IDENT)) error("esperava nome de variável local");
        std::string name = id_val; lexico();
        int array_len = -1;
        if (check(Token::LBRACKET)) {
            lexico();
            if (!check(Token::NUMBER)) error("esperava tamanho do array");
            array_len = num_val; lexico();
            expect(Token::RBRACKET, "']'");
        }
        Symbol& s = add_local(name, array_len);
        // inicializador opcional: nome = valor;
        if (array_len < 0 && match(Token::ASSIGN)) {
            if (!check(Token::NUMBER)) error("esperava literal numérico");
            g2(Op::PUSH_CONST, num_val); lexico();
            g2(Op::STORE_LOCAL, s.offset);
        }
        match(Token::SEMICOLON);
    }
    expect(Token::END, "'end' depois de 'local'");
    match(Token::SEMICOLON);
}

void Compiler::parse_private_section()
{
    while (!check(Token::END) && !check(Token::END_OF_FILE)) {
        if (check(Token::INT_KW)) lexico();
        if (!check(Token::IDENT)) error("esperava nome de variável private");
        std::string name = id_val; lexico();
        int array_len = -1;
        if (check(Token::LBRACKET)) {
            lexico();
            if (!check(Token::NUMBER)) error("esperava tamanho do array");
            array_len = num_val; lexico();
            expect(Token::RBRACKET, "']'");
        }
        Symbol& s = add_local(name, array_len);
        // inicializador opcional: nome = valor;
        if (array_len < 0 && match(Token::ASSIGN)) {
            if (!check(Token::NUMBER)) error("esperava literal numérico");
            g2(Op::PUSH_CONST, num_val); lexico();
            g2(Op::STORE_LOCAL, s.offset);
        }
        match(Token::SEMICOLON);
    }
    expect(Token::END, "'end' depois de 'private'");
    match(Token::SEMICOLON);
}

// ============================================================================
// sentencia — dispatcha para o statement correcto
// Equivale ao case ... dentro de sentencia() no divc.cpp
// ============================================================================
void Compiler::sentencia()
{
    switch (pieza) {
        case Token::IF:       lexico(); stmt_if();       break;
        case Token::WHILE:    lexico(); stmt_while();    break;
        case Token::LOOP:     lexico(); stmt_loop();     break;
        case Token::REPEAT:   lexico(); stmt_repeat();   break;
        case Token::FROM:     lexico(); stmt_from();     break;
        case Token::FOR:      lexico(); stmt_for();      break;
        case Token::SWITCH:   lexico(); stmt_switch();   break;
        case Token::FRAME:    lexico(); stmt_frame();    break;
        case Token::RETURN:   lexico(); stmt_return();   break;
        case Token::BREAK:    lexico(); stmt_break();    break;
        case Token::CONTINUE: lexico(); stmt_continue(); break;
        case Token::SEMICOLON: lexico(); break;          // instrução vazia
        case Token::IDENT:    stmt_assign_or_call();     break;
        default:
            error("instrução desconhecida");
    }
}

// ============================================================================
// if (cond) stmts [else stmts] end
// Equivale ao case p_if do divc.cpp
// ============================================================================
void Compiler::stmt_if()
{
    expect(Token::LPAREN, "'('");
    condicion();                     // gera código da condição
    expect(Token::RPAREN, "')'");
    match(Token::SEMICOLON);

    int h1 = hole(Op::JUMP_FALSE);   // im1 — buraco do if

    while (!check(Token::END) && !check(Token::ELSE) && !check(Token::END_OF_FILE))
        sentencia();

    if (match(Token::ELSE)) {
        match(Token::SEMICOLON);
        int h2 = hole(Op::JUMP);     // im2 — salta sobre o else
        patch(h1);                   // tapa buraco do if → aqui começa o else
        while (!check(Token::END) && !check(Token::END_OF_FILE))
            sentencia();
        patch(h2);                   // tapa buraco do jump pós-if
    } else {
        patch(h1);
    }

    expect(Token::END, "'end' depois de 'if'");
    match(Token::SEMICOLON);
}

// ============================================================================
// while (cond) stmts end
// Equivale ao case p_while do divc.cpp:
//   im1 = imem;  condicion(); g2(ljpf,0); im2=imem-1;
//   sentencia(); g2(ljmp,im1); mem[im2]=imem;
// ============================================================================
void Compiler::stmt_while()
{
    int im1 = here();               // início do while (volta aqui no ljmp)

    // guarda posição dos buracos de break/continue para este loop
    int break_base = (int)break_holes.size();
    int cont_base  = (int)cont_holes.size();
    break_holes.push_back(0); break_holes.pop_back(); // não faz nada, só para marcar o nível

    expect(Token::LPAREN, "'('");
    condicion();
    expect(Token::RPAREN, "')'");
    match(Token::SEMICOLON);

    int h_false = hole(Op::JUMP_FALSE);   // im2 — sai do while se falso

    while (!check(Token::END) && !check(Token::END_OF_FILE))
        sentencia();

    expect(Token::END, "'end'");
    match(Token::SEMICOLON);

    g2(Op::JUMP, im1);              // ljmp im1 — volta ao início
    patch(h_false);                 // mem[im2] = imem

    // resolve break holes → saem aqui (depois do loop)
    for (int i = break_base; i < (int)break_holes.size(); i++)
        patch(break_holes[i]);
    break_holes.resize(break_base);

    // resolve continue holes → voltam ao início
    for (int i = cont_base; i < (int)cont_holes.size(); i++)
        vm.code[cont_holes[i]] = im1;
    cont_holes.resize(cont_base);
}

// ============================================================================
// loop stmts end   — loop infinito
// ============================================================================
void Compiler::stmt_loop()
{
    match(Token::SEMICOLON);
    int im1 = here();

    int break_base = (int)break_holes.size();
    int cont_base  = (int)cont_holes.size();

    while (!check(Token::END) && !check(Token::END_OF_FILE))
        sentencia();

    expect(Token::END, "'end' depois de 'loop'");
    match(Token::SEMICOLON);

    g2(Op::JUMP, im1);

    for (int i = break_base; i < (int)break_holes.size(); i++)
        patch(break_holes[i]);
    break_holes.resize(break_base);

    for (int i = cont_base; i < (int)cont_holes.size(); i++)
        vm.code[cont_holes[i]] = im1;
    cont_holes.resize(cont_base);
}

// ============================================================================
// repeat stmts until (cond)
// Equivale ao case p_repeat do divc.cpp:
//   im1=imem; sentencia(); condicion(); g2(ljpf,im1);
//
// Diferença de while: executa SEMPRE pelo menos uma vez,
// e sai quando condição é VERDADEIRA (oposto do while).
// ============================================================================
void Compiler::stmt_repeat()
{
    match(Token::SEMICOLON);

    int im1 = here();   // início do body

    int break_base = (int)break_holes.size();
    int cont_base  = (int)cont_holes.size();

    while (!check(Token::UNTIL) && !check(Token::END_OF_FILE))
        sentencia();

    expect(Token::UNTIL, "'until' depois de 'repeat'");

    // until (condição) — sai quando verdadeiro, repete quando falso
    expect(Token::LPAREN, "'('");
    condicion();
    expect(Token::RPAREN, "')'");
    match(Token::SEMICOLON);

    g2(Op::JUMP_FALSE, im1);    // ljpf im1 — repete se condição falsa

    // break → aqui (depois do until); continue → im1 (início do body)
    for (int i = break_base; i < (int)break_holes.size(); i++)  patch(break_holes[i]);
    break_holes.resize(break_base);
    for (int i = cont_base;  i < (int)cont_holes.size();  i++)  vm.code[cont_holes[i]] = im1;
    cont_holes.resize(cont_base);
}

// ============================================================================
// for (init; cond; incr) stmts end
// Equivale ao case p_for do divc.cpp.
//
// Layout do bytecode (igual ao DIV):
//   [init]               ← stmt_assign_or_call(); consome o ';' do init
//   [im1]: cond; JUMP_FALSE [end]
//          JUMP [body]   ← 1ª iteração salta o incremento
//   [im4]: incr          ← continue aponta aqui
//          JUMP [im1]
//   [body]: stmts
//           JUMP [im4]
//   [end]:
// ============================================================================
void Compiler::stmt_for()
{
    expect(Token::LPAREN, "'('");

    int break_base = (int)break_holes.size();
    int cont_base  = (int)cont_holes.size();

    // 1. Init — atribuição(ões) ou vazio
    //    stmt_assign_or_call() consome o seu próprio ';' (= o primeiro ';' do for)
    if (check(Token::SEMICOLON)) {
        lexico();  // init vazio — consome ';'
    } else if (check(Token::IDENT)) {
        stmt_assign_or_call();  // consome o ';' que separa init da condição
    }
    // Neste ponto já estamos imediatamente antes da condição

    int im1 = here();   // início da condição

    // 2. Condição — ou vazio (= true)
    if (check(Token::SEMICOLON)) {
        g2(Op::PUSH_CONST, 1);
        lexico();
    } else {
        condicion();
        expect(Token::SEMICOLON, "';' depois de condição");
    }
    int h_end  = hole(Op::JUMP_FALSE);  // im2 — sai se falso
    int h_body = hole(Op::JUMP);        // im3 — salta incremento na 1ª iteração

    // 3. Incremento — sem ';' obrigatório (termina com ')')
    int im4 = here();  // continue aponta aqui
    if (!check(Token::RPAREN) && check(Token::IDENT)) {
        stmt_assign_or_call();  // match(';') é opcional — não encontra ';' aqui
    }
    expect(Token::RPAREN, "')'");
    match(Token::SEMICOLON);  // ';' opcional após ')'

    g2(Op::JUMP, im1);  // depois do incremento → re-verifica condição
    patch(h_body);      // body começa aqui

    // 4. Body
    while (!check(Token::END) && !check(Token::END_OF_FILE))
        sentencia();
    expect(Token::END, "'end' depois de 'for'");
    match(Token::SEMICOLON);

    g2(Op::JUMP, im4);  // fim do body → executa incremento
    patch(h_end);       // end do loop

    for (int i = break_base; i < (int)break_holes.size(); i++)  patch(break_holes[i]);
    break_holes.resize(break_base);
    for (int i = cont_base;  i < (int)cont_holes.size();  i++)  vm.code[cont_holes[i]] = im4;
    cont_holes.resize(cont_base);
}

// ============================================================================
// switch (expr)
//   case V:       stmts end
//   case Lo..Hi:  stmts end    ← range (= lcsr do DIV)
//   default:      stmts end
// end
//
// Equivale ao case p_switch do divc.cpp.
//
// O valor do switch permanece na stack durante toda a execução
// (= a stack do DIV tem o valor ao longo do switch inteiro).
// Cada CASE_EQ/CASE_RNG compara sem consumir o switch_val.
// O POP final (ou no início do body) consome o switch_val.
// ============================================================================
void Compiler::stmt_switch()
{
    // switch (expr) — valor fica na stack
    expect(Token::LPAREN, "'('");
    condicion();
    expect(Token::RPAREN, "')'");
    while (check(Token::SEMICOLON)) lexico();

    int im1 = 0;   // buraco do último CASE_EQ/CASE_RNG não correspondido
    int im2 = 0;   // linked list de JMPs para o end (= im2 do DIV)

    while (!check(Token::END) && !check(Token::END_OF_FILE)) {
        if (check(Token::CASE)) {
            lexico();  // consome 'case'

            // pode ter múltiplos valores: case 1, 3, 5:
            // im3 = linked list de JMPs para o body (multi-value)
            int im3 = 0;
            do {
                if (im1) patch(im1);    // tapa buraco do case anterior (falhou → tenta este)

                // valor inferior / único
                expr();

                if (check(Token::DOTDOT)) {
                    // case Lo..Hi  (= lcsr do DIV)
                    lexico();
                    expr();                        // valor superior
                    int h = (int)vm.code.size();
                    g2(Op::CASE_RNG, 0); im1 = h + 1;
                } else {
                    // case V  (= lcse do DIV)
                    int h = (int)vm.code.size();
                    g2(Op::CASE_EQ, 0); im1 = h + 1;
                }

                if (check(Token::COMMA)) {
                    // múltiplos valores: se match → salta para o body
                    lexico();
                    int h = (int)vm.code.size();
                    vm.code.push_back(static_cast<int>(Op::JUMP));
                    vm.code.push_back(im3);  // linked list
                    im3 = h + 1;
                }
            } while (check(Token::COMMA));

            // resolve os JMPs dos valores multi-case → body
            while (im3) { int nxt = vm.code[im3]; vm.code[im3] = here(); im3 = nxt; }

        } else if (check(Token::DEFAULT)) {
            lexico();
            if (im1) { patch(im1); im1 = 0; }  // default: tapa o buraco do último case
        } else {
            error("esperava 'case' ou 'default' dentro de 'switch'");
        }

        while (check(Token::SEMICOLON) || check(Token::COMMA) || check(Token::COLON)) lexico();

        // POP o switch_val antes do body (= lasp do DIV)
        g1(Op::POP);

        // body do case — até 'end'
        while (!check(Token::END) && !check(Token::END_OF_FILE))
            sentencia();
        expect(Token::END, "'end' dentro de 'switch'");
        match(Token::SEMICOLON);

        // JUMP para o end do switch (break implícito)
        int h = (int)vm.code.size();
        vm.code.push_back(static_cast<int>(Op::JUMP));
        vm.code.push_back(im2);  // linked list de JMPs para end
        im2 = h + 1;
    }

    // fim do switch
    expect(Token::END, "'end' depois de 'switch'");
    match(Token::SEMICOLON);

    // último case não correspondeu e não há default → cai aqui, descarta switch_val
    if (im1) patch(im1);
    g1(Op::POP);   // = lasp: descarta switch_val (sem match ou após default)

    // resolve todos os JMPs de break implícito → aqui
    while (im2) { int nxt = vm.code[im2]; vm.code[im2] = here(); im2 = nxt; }
}

// ============================================================================
// from x = A to B [step S]; stmts end
// Equivale ao case p_from do divc.cpp
// ============================================================================
void Compiler::stmt_from()
{
    if (!check(Token::IDENT)) error("esperava variável em 'from'");
    std::string var = id_val; lexico();

    expect(Token::ASSIGN, "'='");

    // valor inicial
    if (!check(Token::NUMBER)) error("esperava número em 'from'");
    int from_val = num_val; lexico();

    expect(Token::TO, "'to'");

    if (!check(Token::NUMBER)) error("esperava número em 'to'");
    int to_val = num_val; lexico();

    int step_val = (from_val <= to_val) ? 1 : -1;
    if (match(Token::STEP)) {
        if (!check(Token::NUMBER)) error("esperava número em 'step'");
        step_val = num_val; lexico();
    }
    match(Token::SEMICOLON);

    // var = from_val
    Symbol* s = find_sym(var);
    if (!s) error("variável não declarada: " + var);

    g2(Op::PUSH_CONST, from_val);
    if (s->kind == SymKind::GLOBAL) g2(Op::STORE_GLOBAL, s->offset);
    else                            g2(Op::STORE_LOCAL,  s->offset);

    int im1 = here();   // início do loop from

    int break_base = (int)break_holes.size();
    int cont_base  = (int)cont_holes.size();

    // condição: var <= to_val  (ou >= se step negativo)
    if (s->kind == SymKind::GLOBAL) g2(Op::LOAD_GLOBAL, s->offset);
    else                            g2(Op::LOAD_LOCAL,  s->offset);
    g2(Op::PUSH_CONST, to_val);
    if (step_val > 0) g1(Op::LTE); else g1(Op::GTE);

    int h_false = hole(Op::JUMP_FALSE);

    while (!check(Token::END) && !check(Token::END_OF_FILE))
        sentencia();

    expect(Token::END, "'end' depois de 'from'");
    match(Token::SEMICOLON);

    int cont_target = here();   // continue volta aqui (incremento)

    // var += step
    if (s->kind == SymKind::GLOBAL) g2(Op::LOAD_GLOBAL, s->offset);
    else                            g2(Op::LOAD_LOCAL,  s->offset);
    g2(Op::PUSH_CONST, step_val);
    g1(Op::ADD);
    if (s->kind == SymKind::GLOBAL) g2(Op::STORE_GLOBAL, s->offset);
    else                            g2(Op::STORE_LOCAL,  s->offset);

    g2(Op::JUMP, im1);
    patch(h_false);

    for (int i = break_base; i < (int)break_holes.size(); i++)  patch(break_holes[i]);
    break_holes.resize(break_base);
    for (int i = cont_base;  i < (int)cont_holes.size();  i++)  vm.code[cont_holes[i]] = cont_target;
    cont_holes.resize(cont_base);
}

// ============================================================================
// frame;  ou  frame(n);
// ============================================================================
void Compiler::stmt_frame()
{
    if (match(Token::LPAREN)) {
        if (!check(Token::NUMBER)) error("esperava número em frame(n)");
        int n = num_val; lexico();
        expect(Token::RPAREN, "')'");
        g2(Op::FRAME_N, n);   // lfrf
    } else {
        g1(Op::FRAME);        // lfrm
    }
    match(Token::SEMICOLON);
}

// ============================================================================
// return;
// ============================================================================
void Compiler::stmt_return()
{
    if (in_function) {
        // return expr;  ou  return;  (sem valor → retorna 0)
        if (!check(Token::SEMICOLON) && !check(Token::END_OF_FILE) && !check(Token::END))
            expr();
        else
            g2(Op::PUSH_CONST, 0);
        match(Token::SEMICOLON);
        g1(Op::FUNC_RET);
    } else {
        g1(Op::RETURN);
        match(Token::SEMICOLON);
    }
}

// ============================================================================
// break;
// ============================================================================
void Compiler::stmt_break()
{
    int h = hole(Op::JUMP);   // buraco resolvido no end do loop
    break_holes.push_back(h);
    match(Token::SEMICOLON);
}

// ============================================================================
// continue;
// ============================================================================
void Compiler::stmt_continue()
{
    int h = hole(Op::JUMP);
    cont_holes.push_back(h);
    match(Token::SEMICOLON);
}

// ============================================================================
// stmt_assign_or_call — despacha atribuições, chamadas, arrays, ++ --
//
// Suporta (fiel ao DIV):
//   x = expr;           → STORE_GLOBAL / STORE_LOCAL
//   x[i] = expr;        → STORE_GLOBAL_IDX / STORE_LOCAL_IDX
//   x += expr;          → LOAD, expr, ADD, STORE
//   x[i] += expr;       → idx, DUP, LOAD_IDX, expr, ADD, STORE_IDX
//   x++;  x--;          → LOAD, PUSH 1, ADD/SUB, STORE
//   proc();             → SPAWN / CALL_BUILTIN
// ============================================================================
void Compiler::stmt_assign_or_call()
{
    std::string name = id_val; lexico();
    Symbol* s = find_sym(name);

    // --- chamada de função/processo ---
    if (check(Token::LPAREN)) {
        lexico();

        if (s && s->kind == SymKind::BUILTIN) {
            int nargs = 0;
            if (!check(Token::RPAREN)) {
                do { expr(); nargs++; } while (match(Token::COMMA));
            }
            expect(Token::RPAREN, "')'");
            match(Token::SEMICOLON);
            g2(Op::CALL_BUILTIN, s->offset);
            return;
        }

        if (s && s->kind == SymKind::FUNCTION) {
            int nargs = 0;
            if (!check(Token::RPAREN)) {
                do { expr(); nargs++; } while (match(Token::COMMA));
            }
            expect(Token::RPAREN, "')'");
            match(Token::SEMICOLON);
            g3(Op::FUNC_CALL, s->offset, nargs);
            g1(Op::POP);  // descarta valor de retorno (chamada como statement)
            return;
        }

        // spawn de processo
        expect(Token::RPAREN, "')'");
        match(Token::SEMICOLON);

        if (s && s->kind == SymKind::PROCESS) {
            g3(Op::SPAWN, s->offset, 100);
            g1(Op::POP);
        } else {
            vm.code.push_back(static_cast<int>(Op::SPAWN));
            int h = (int)vm.code.size(); vm.code.push_back(0);
            vm.code.push_back(100);
            g1(Op::POP);
            forward_holes[name].push_back(h);
        }
        return;
    }

    if (!s || (s->kind != SymKind::GLOBAL && s->kind != SymKind::LOCAL))
        error("variável não declarada: " + name);

    bool is_global = (s->kind == SymKind::GLOBAL);
    int  base      = s->offset;

    // --- array: name[idx] ---
    if (check(Token::LBRACKET)) {
        lexico();
        expr();                                     // compila índice → stack
        expect(Token::RBRACKET, "']'");

        Token op = pieza;
        if (op == Token::ASSIGN) {
            // a[i] = expr
            lexico();
            expr();
            match(Token::SEMICOLON);
            // stack: [..., idx, val]
            if (is_global) g2(Op::STORE_GLOBAL_IDX, base);
            else           g2(Op::STORE_LOCAL_IDX,  base);

        } else if (op == Token::ADD_ASSIGN || op == Token::SUB_ASSIGN ||
                   op == Token::MUL_ASSIGN || op == Token::DIV_ASSIGN ||
                   op == Token::MOD_ASSIGN) {
            // a[i] += expr  →  DUP, LOAD_IDX, expr, op, STORE_IDX
            lexico();
            g1(Op::DUP);    // duplica idx: [..., idx, idx]
            if (is_global) g2(Op::LOAD_GLOBAL_IDX, base);
            else           g2(Op::LOAD_LOCAL_IDX,  base);  // [..., idx, a[i]]
            expr();
            match(Token::SEMICOLON);
            switch (op) {
                case Token::ADD_ASSIGN: g1(Op::ADD); break;
                case Token::SUB_ASSIGN: g1(Op::SUB); break;
                case Token::MUL_ASSIGN: g1(Op::MUL); break;
                case Token::DIV_ASSIGN: g1(Op::DIV); break;
                case Token::MOD_ASSIGN: g1(Op::MOD); break;
                default: break;
            }
            // stack: [..., idx, result]
            if (is_global) g2(Op::STORE_GLOBAL_IDX, base);
            else           g2(Op::STORE_LOCAL_IDX,  base);
        } else {
            error("operador de atribuição esperado depois de 'name[i]'");
        }
        return;
    }

    // --- escalar: name ---
    Token op = pieza;

    if (op == Token::ASSIGN) {
        // x = expr
        lexico(); expr();
        match(Token::SEMICOLON);
        if (is_global) g2(Op::STORE_GLOBAL, base);
        else           g2(Op::STORE_LOCAL,  base);

    } else if (op == Token::ADD_ASSIGN || op == Token::SUB_ASSIGN ||
               op == Token::MUL_ASSIGN || op == Token::DIV_ASSIGN ||
               op == Token::MOD_ASSIGN) {
        // x += expr  →  LOAD, expr, op, STORE
        lexico();
        if (is_global) g2(Op::LOAD_GLOBAL, base);
        else           g2(Op::LOAD_LOCAL,  base);
        expr();
        match(Token::SEMICOLON);
        switch (op) {
            case Token::ADD_ASSIGN: g1(Op::ADD); break;
            case Token::SUB_ASSIGN: g1(Op::SUB); break;
            case Token::MUL_ASSIGN: g1(Op::MUL); break;
            case Token::DIV_ASSIGN: g1(Op::DIV); break;
            case Token::MOD_ASSIGN: g1(Op::MOD); break;
            default: break;
        }
        if (is_global) g2(Op::STORE_GLOBAL, base);
        else           g2(Op::STORE_LOCAL,  base);

    } else if (op == Token::INC || op == Token::DEC) {
        // x++  →  LOAD, PUSH 1, ADD, STORE  (= linc/ldec do DIV)
        lexico();
        match(Token::SEMICOLON);
        if (is_global) g2(Op::LOAD_GLOBAL, base);
        else           g2(Op::LOAD_LOCAL,  base);
        g2(Op::PUSH_CONST, 1);
        g1(op == Token::INC ? Op::ADD : Op::SUB);
        if (is_global) g2(Op::STORE_GLOBAL, base);
        else           g2(Op::STORE_LOCAL,  base);

    } else {
        error("operador de atribuição esperado: " + name);
    }
}

// ============================================================================
// condicion — expressão com comparações e lógica AND/OR
// Equivale à condicion() + condicion_and() do DIV
// Deixa 1 ou 0 no topo da stack
// ============================================================================
void Compiler::condicion()
{
    // Nível OR (menor prioridade) — = | ou || no DIV
    expr();
    Token op = pieza;
    if (op==Token::EQ_OP || op==Token::NEQ || op==Token::GT ||
        op==Token::LT    || op==Token::GTE || op==Token::LTE) {
        lexico(); expr();
        switch (op) {
            case Token::EQ_OP: g1(Op::EQ);  break;
            case Token::NEQ:   g1(Op::NEQ); break;
            case Token::GT:    g1(Op::GT);  break;
            case Token::LT:    g1(Op::LT);  break;
            case Token::GTE:   g1(Op::GTE); break;
            case Token::LTE:   g1(Op::LTE); break;
            default: break;
        }
    }
    // AND/OR em cadeias: (a > 0) && (b > 0)  ou  a > 0 and b > 0
    while (check(Token::AND_OP) || check(Token::AND_KW) ||
           check(Token::OR_OP)  || check(Token::OR_KW)  ||
           check(Token::BAND_OP)|| check(Token::BOR_OP) || check(Token::BXOR_OP)) {
        Token lop = pieza; lexico();
        condicion_atom();
        switch (lop) {
            case Token::AND_OP: case Token::AND_KW:  g1(Op::AND);  break;
            case Token::OR_OP:  case Token::OR_KW:   g1(Op::OR);   break;
            case Token::BAND_OP:                     g1(Op::BAND); break;
            case Token::BOR_OP:                      g1(Op::BOR);  break;
            case Token::BXOR_OP:                     g1(Op::BXOR); break;
            default: break;
        }
    }
}

// Un átomo de condição (expr + operador relacional opcional)
void Compiler::condicion_atom()
{
    expr();
    Token op = pieza;
    if (op==Token::EQ_OP || op==Token::NEQ || op==Token::GT ||
        op==Token::LT    || op==Token::GTE || op==Token::LTE) {
        lexico(); expr();
        switch (op) {
            case Token::EQ_OP: g1(Op::EQ);  break;
            case Token::NEQ:   g1(Op::NEQ); break;
            case Token::GT:    g1(Op::GT);  break;
            case Token::LT:    g1(Op::LT);  break;
            case Token::GTE:   g1(Op::GTE); break;
            case Token::LTE:   g1(Op::LTE); break;
            default: break;
        }
    }
}

// ============================================================================
// expr — adição, subtracção, bitwise OR
// ============================================================================
void Compiler::expr()
{
    term();
    while (check(Token::PLUS) || check(Token::MINUS) || check(Token::BOR_OP)) {
        Token op = pieza; lexico();
        term();
        switch (op) {
            case Token::PLUS:   g1(Op::ADD); break;
            case Token::MINUS:  g1(Op::SUB); break;
            case Token::BOR_OP: g1(Op::BOR); break;
            default: break;
        }
    }
}

// ============================================================================
// term — multiplicação, divisão, módulo, bitwise
// ============================================================================
void Compiler::term()
{
    factor();
    while (check(Token::STAR)   || check(Token::SLASH) || check(Token::MOD_OP) ||
           check(Token::BAND_OP)|| check(Token::BXOR_OP)) {
        Token op = pieza; lexico();
        factor();
        switch (op) {
            case Token::STAR:    g1(Op::MUL);  break;
            case Token::SLASH:   g1(Op::DIV);  break;
            case Token::MOD_OP:  g1(Op::MOD);  break;
            case Token::BAND_OP: g1(Op::BAND); break;
            case Token::BXOR_OP: g1(Op::BXOR); break;
            default: break;
        }
    }
}

// ============================================================================
// ============================================================================
// factor — literal, variável, array[idx], (expr), NOT, ~, -
// ============================================================================
void Compiler::factor()
{
    if (check(Token::NUMBER)) {
        g2(Op::PUSH_CONST, num_val);
        lexico();
        return;
    }
    if (check(Token::MINUS)) {
        lexico(); factor(); g1(Op::NEG);
        return;
    }
    // ! expr  (= lnot do DIV) e  ~ expr  (= bnot)
    if (check(Token::NOT_OP) || check(Token::NOT_KW)) {
        lexico(); factor(); g1(Op::NOT);
        return;
    }
    if (check(Token::BXOR_OP)) {  // ^ usado como ~ (bitwise NOT unário)
        lexico(); factor(); g1(Op::BNOT);
        return;
    }
    if (check(Token::LPAREN)) {
        lexico(); condicion();
        expect(Token::RPAREN, "')'");
        return;
    }
    if (check(Token::IDENT)) {
        std::string name = id_val; lexico();

        // chamada de função ou builtin com retorno: soma(a,b), abs(x), etc.
        if (check(Token::LPAREN)) {
            lexico();
            Symbol* s = find_sym(name);
            if (!s) error("função não declarada: " + name);

            // colecta argumentos separados por vírgula
            int nargs = 0;
            if (!check(Token::RPAREN)) {
                do { expr(); nargs++; } while (match(Token::COMMA));
            }
            expect(Token::RPAREN, "')'");

            if (s->kind == SymKind::BUILTIN) {
                g2(Op::CALL_BUILTIN, s->offset);
            } else if (s->kind == SymKind::FUNCTION) {
                g3(Op::FUNC_CALL, s->offset, nargs);
            } else {
                error("'" + name + "' não é uma função");
            }
            return;
        }

        Symbol* s = find_sym(name);
        if (!s) error("variável não declarada: " + name);

        // array[idx]  — acesso com índice runtime (= lptr do DIV)
        if (check(Token::LBRACKET)) {
            lexico();
            expr();                             // compila índice
            expect(Token::RBRACKET, "']'");
            if (s->kind == SymKind::GLOBAL) g2(Op::LOAD_GLOBAL_IDX, s->offset);
            else                            g2(Op::LOAD_LOCAL_IDX,  s->offset);
            return;
        }

        // escalar
        if (s->kind == SymKind::GLOBAL) g2(Op::LOAD_GLOBAL, s->offset);
        else                            g2(Op::LOAD_LOCAL,  s->offset);
        return;
    }
    error("factor inválido");
}
