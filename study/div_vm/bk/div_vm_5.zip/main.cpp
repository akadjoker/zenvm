// main.cpp — escreve código DIV como string, compila e corre
#include <chrono>
#include <cstdio>
#include <cstring>
#include "vm.hpp"
#include "compiler.hpp"
#include "process.hpp"

static const char* PROGRAM = R"(

global
    string greeting = "ola mundo";
    float pi = 3.5;
end

process filho(label, ratio)
begin
    write(label);
    write(ratio);
    return;
end

function soma(a, b)
begin
    return a + b + 0.5;
end

process main()
local
    string title = "main";
end
begin
    write(greeting);
    write(pi);
    write(title);
    write(soma(2.25, 3.5));
    filho("filho", 1.5);
    frame;
    return;
end

)";

// ---------------------------------------------------------------------------
// Builtins
// ---------------------------------------------------------------------------

static void builtin_write(VM& vm) {
    Value v = vm.pop();
    Process& me = vm.current_process();
    printf("  [%s]  ", me.name.c_str());
    vm.print_value(v);
    printf("\n");
}

static int clock_ms_now()
{
    using clock = std::chrono::steady_clock;
    static const clock::time_point start = clock::now();
    const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(clock::now() - start);
    return static_cast<int>(elapsed.count());
}

static void builtin_clock(VM& vm)
{
    vm.push(Value::make_int(clock_ms_now()));
}

int main(int argc, char* argv[])
{
    bool do_dis         = false;
    bool do_trace       = false;
    bool do_parse_trace = false;
    bool quiet          = false;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--dis"))         do_dis = true;
        if (!strcmp(argv[i], "--trace"))       do_trace = true;
        if (!strcmp(argv[i], "--parse-trace")) do_parse_trace = true;
        if (!strcmp(argv[i], "--quiet"))       quiet = true;
    }

    VM vm(16, 2048);
    Compiler compiler(vm);
    compiler.trace_parse = do_parse_trace;

    compiler.register_builtin("write", vm.add_builtin(builtin_write));
    compiler.register_builtin("clock", vm.add_builtin(builtin_clock));

    printf("=== compilar ===\n");
    try {
        compiler.compile(PROGRAM);
    } catch (const std::exception& e) {
        printf("ERRO: %s\n", e.what());
        return 1;
    }
    printf("código: %zu words\n\n", vm.code.size());

    if (do_dis) {
        vm.disassemble();
        if (!do_trace) return 0;   // só disassembla, não corre
    }

    vm.trace_ops = do_trace;
    vm.verbose   = !quiet;

    int main_entry = compiler.entry_of("main");
    if (main_entry < 0) { printf("'main' não encontrado\n"); return 1; }

    vm.run(main_entry, "main", 100);
    printf("\n=== fim ===\n");
    return 0;
}

