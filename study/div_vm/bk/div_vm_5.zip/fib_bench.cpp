#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <string>

#include "compiler.hpp"
#include "process.hpp"
#include "vm.hpp"

static int parse_arg(const char* text, int fallback)
{
    if (!text || !*text)
        return fallback;

    char* end = nullptr;
    long value = std::strtol(text, &end, 10);
    if (!end || *end != '\0')
        return fallback;
    return static_cast<int>(value);
}

static std::string make_program(int n, int repeats)
{
    return "function fib(n)\n"
           "begin\n"
           "    if (n <= 1)\n"
           "        return n;\n"
           "    end\n"
           "    return fib(n - 1) + fib(n - 2);\n"
           "end\n\n"
           "process main()\n"
           "local\n"
           "    int i = 0;\n"
           "    int acc = 0;\n"
           "    int start_ms = 0;\n"
           "    int elapsed_ms = 0;\n"
           "end\n"
           "begin\n"
           "    start_ms = clock();\n"
           "    while (i < " + std::to_string(repeats) + ")\n"
           "        acc += fib(" + std::to_string(n) + ");\n"
           "        i++;\n"
           "    end\n"
           "    elapsed_ms = clock() - start_ms;\n"
           "    write(acc);\n"
           "    write(elapsed_ms);\n"
           "    return;\n"
           "end\n";
}

static void builtin_write_raw(VM& vm)
{
    Value value = vm.pop();
    vm.print_value(value);
    std::printf("\n");
}

static int clock_ms_now()
{
    using clock = std::chrono::steady_clock;
    static const clock::time_point start = clock::now();
    const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(clock::now() - start);
    return static_cast<int>(elapsed.count());
}

static void builtin_clock(VM& vm)
{
    vm.push(Value::make_int(clock_ms_now()));
}

int main(int argc, char* argv[])
{
    const int n = parse_arg(argc > 1 ? argv[1] : nullptr, 30);
    const int repeats = parse_arg(argc > 2 ? argv[2] : nullptr, 1);

    VM vm(16, 4096);
    Compiler compiler(vm);
    compiler.register_builtin("write", vm.add_builtin(builtin_write_raw));
    compiler.register_builtin("clock", vm.add_builtin(builtin_clock));

    try {
        compiler.compile(make_program(n, repeats));
    } catch (const std::exception& e) {
        std::fprintf(stderr, "compile error: %s\n", e.what());
        return 1;
    }

    vm.verbose = false;
    vm.trace_ops = false;

    const int main_entry = compiler.entry_of("main");
    if (main_entry < 0) {
        std::fputs("main not found\n", stderr);
        return 2;
    }

    vm.run(main_entry, "main", 100);
    return 0;
}