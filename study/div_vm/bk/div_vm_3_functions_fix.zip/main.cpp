// main.cpp — escreve código DIV como string, compila e corre
#include <cstdio>
#include <cmath>
#include "vm.hpp"
#include "compiler.hpp"
#include "process.hpp"

// Testa funções inline com parâmetros e valor de retorno

static const char* PROGRAM = R"(

global
    resultado = 0;
end

// função com variável local 'acum'
function soma_ate(n)
begin
    return n * (n + 1) / 2;
end

// função recursiva com local implícito (parâmetro)
function fact(n)
begin
    if (n <= 1)
        return 1;
    end
    return n * fact(n - 1);
end

// processo com variáveis locais próprias
process contador()
private
    passo = 0;
    limite = 0;
end
begin
    passo  = 3;
    limite = 15;
    loop
        x = x + passo;
        if (x >= limite)
            return;
        end
        write_int(x);
        frame;
    end
end

process main()
private
    a = 0;
    b = 0;
end
begin
    // testa locais no processo
    a = soma_ate(10);    // 55
    b = fact(5);         // 120
    write_int(a);
    write_int(b);

    // lança processo com locals próprias
    contador();
    frame; frame; frame; frame; frame;
    return;
end

)";

// ---------------------------------------------------------------------------
// Builtins
// ---------------------------------------------------------------------------

// write_int(n) — imprime um valor inteiro
static void builtin_write_int(VM& vm) {
    int v = vm.pop();
    Process& me = vm.current_process();
    printf("  [%s]  %d\n", me.name.c_str(), v);
}

int main()
{
    VM vm(16, 2048);
    Compiler compiler(vm);

    compiler.register_builtin("write_int", vm.add_builtin(builtin_write_int));

    printf("=== compilar ===\n");
    try {
        compiler.compile(PROGRAM);
    } catch (const std::exception& e) {
        printf("ERRO: %s\n", e.what());
        return 1;
    }
    printf("código: %zu words\n\n", vm.code.size());

    int main_entry = compiler.entry_of("main");
    if (main_entry < 0) { printf("'main' não encontrado\n"); return 1; }

    vm.run(main_entry, "main", 100);
    printf("\n=== fim ===\n");
    return 0;
}

